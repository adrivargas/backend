export class CreateMenuItemDto {
  name!: string;
  price!: number;
  sizes?: string[];
}
